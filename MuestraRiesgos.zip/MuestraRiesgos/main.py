import streamlit as st
import pandas as pd
import plotly.express as px
import datetime

# --- CONFIGURACION INICIAL ---
st.set_page_config(page_title="Radar de Riesgo - Smart Coolers", layout="wide")

# --- CARGAR DATOS ---
@st.cache_data
def load_data():
    df = pd.read_csv("predicciones_mayo2025.csv")
    df.columns = [col.strip().lower() for col in df.columns]
    df.rename(columns={"probabilidad_falla": "prob_failure"}, inplace=True)
    df["predicted_failure"] = (df["prob_failure"] >= 0.5).astype(int)
    return df.sort_values(by="prob_failure", ascending=False)

df = load_data()

# --- CLASIFICACION DE RIESGO ---
def clasificar_riesgo(p):
    if p >= 0.8:
        return "Alto"
    elif p >= 0.5:
        return "Medio"
    return "Bajo"

df["nivel_riesgo"] = df["prob_failure"].apply(clasificar_riesgo)

# --- METRICAS GENERALES ---
st.title("🧊 Radar de Riesgo en Enfriadores - Mayo 2025")
st.markdown("""
Este radar predice la probabilidad de falla de enfriadores en el mes de mayo 2025 con base en señales de sensores (temperatura, energía, aperturas, etc.). 

🎯 **Objetivo:** Priorizar enfriadores con mayor probabilidad de falla para generar órdenes de trabajo preventivas.

🔍 **Contexto:** Los enfriadores con falla pierden capacidad de enfriar producto, lo que reduce la disponibilidad de producto listo para consumir y afecta las ventas.
""")

col1, col2, col3, col4 = st.columns(4)
col1.metric("🔢 Total Enfriadores", len(df))
col2.metric("🚨 Riesgo Alto", f"{(df['nivel_riesgo'] == 'Alto').mean():.1%}")
col3.metric("⚠️ Riesgo Medio", f"{(df['nivel_riesgo'] == 'Medio').mean():.1%}")
col4.metric("✅ Riesgo Bajo", f"{(df['nivel_riesgo'] == 'Bajo').mean():.1%}")

# --- FILTROS ---
riesgo_sel = st.multiselect(
    "Filtrar por nivel de riesgo:",
    ["Alto", "Medio", "Bajo"],
    default=["Alto", "Medio"]
)
df = df[df["nivel_riesgo"].isin(riesgo_sel)]

# --- SLIDER TOP N ---
top_n = st.slider("Seleccionar número de enfriadores más críticos a mostrar", 5, 100, 10)
top_df = df.head(top_n)

# --- VISUALIZACION INDIVIDUAL ---
st.subheader("📌 Enfriadores Priorizados")
for _, row in top_df.iterrows():
    riesgo = row["prob_failure"]
    cooler_id = row["cooler_id"]
    pred = row["predicted_failure"]
    bar_color = "#2ecc71" if riesgo < 0.5 else ("#f1c40f" if riesgo < 0.8 else "#e74c3c")

    st.markdown(f"**🣨 Cooler ID: `{cooler_id}`**")
    st.markdown(f"""
    <div style='background-color: lightgray; border-radius: 5px; overflow: hidden;'>
      <div style='width: {riesgo*100:.1f}%; background-color: {bar_color}; padding: 4px;'>
        {riesgo*100:.1f}% probabilidad de falla
      </div>
    </div>
    """, unsafe_allow_html=True)

    with st.expander("🔎 Diagnóstico y acción sugerida"):
        st.write(f"- Nivel de riesgo: {row['nivel_riesgo']}")
        st.write(f"- Probabilidad de falla: {riesgo*100:.1f}%")
        st.write(f"- Predicción binaria: {pred}")
        if riesgo > 0.8:
            st.error("🚨 Acción: Generar orden de trabajo urgente para mantenimiento técnico")
        elif riesgo > 0.5:
            st.warning("⚠️ Acción: Programar visita técnica preventiva esta semana")
        else:
            st.success("✅ Estado: Enfriador saludable. Monitorear periódicamente.")

# --- GRAFICO PIE ---
st.subheader("📈 Proporción de Enfriadores por Nivel de Riesgo")
pie_fig = px.pie(
    df, names="nivel_riesgo", title="Distribución de Riesgo",
    color_discrete_map={"Alto": "#e74c3c", "Medio": "#f1c40f", "Bajo": "#2ecc71"}
)
st.plotly_chart(pie_fig, use_container_width=True)

# --- IMPACTO ECONÓMICO ESTIMADO ---
dias_salvados = 2
venta_diaria_prom = 500  # MXN por día por cooler
fallas_criticas = df[df["prob_failure"] >= 0.8]
impacto_estimado = len(fallas_criticas) * dias_salvados * venta_diaria_prom

st.subheader("💰 Impacto Económico Estimado por Prevención de Fallas")
st.markdown(f"""
- Coolers en riesgo crítico (≥ 80%): **{len(fallas_criticas)}**
- Días anticipados por predicción: **{dias_salvados} días**
- Venta diaria promedio por cooler: **${venta_diaria_prom}**

📈 **Impacto económico estimado: ${impacto_estimado:,.2f} MXN**
""")

# --- TABLA ---
st.subheader("📄 Tabla de Enfriadores Seleccionados")
st.dataframe(top_df[["cooler_id", "prob_failure", "predicted_failure", "nivel_riesgo"]])

# --- EXPORTAR CSV ---
st.subheader("💾 Exportar resultados")
csv = top_df.to_csv(index=False).encode('utf-8')
st.download_button(
    label="Descargar CSV filtrado",
    data=csv,
    file_name=f"top_coolers_export_{datetime.date.today().isoformat()}.csv",
    mime='text/csv'
)
